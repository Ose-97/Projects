"""
Osemudianmen Aisuodionoe-Shadrach
CS 108 PROJECT
The User-friendly 2 Player Pong Game
"""
import pygame
import sys
from math import *
import random
import colorama
from colorama import Fore, Style

pygame.init()
colorama.init(autoreset=True) #to edit colors in the shell

# Setting values for the display dimension
width = 900
height = 400
display = pygame.display.set_mode((width, height))                      
pygame.display.set_caption("The User-Friendly 2 PLAYER Pong Game")
clock = pygame.time.Clock()

#colors and their RGB values 
default_background = (27, 38, 49)
white = (236, 240, 241)
red = (203, 67, 53)
green = (118,238,0)
blue = (52, 152, 219)               #written by me
yellow = (244, 208, 63)
black = (0,0,0)
darkorange = (139,69,0)
aquamarine = (69,139,116)

# black color for borders
top = black
bottom = black                      #written by me
left = black
right = black
margin = 4

#initial user scores, max score and paddle speed
left_players_score = 0
right_players_score = 0
maximum_score_limit = 0                                    #written by me
paddlespeed = 0

#font for the score display and winner display
font = pygame.font.SysFont("Arial", 40)
largeFont = pygame.font.SysFont("Small Fonts", 70)

def print_colored(text, color=None):
    if color is not None:
        if isinstance(color, tuple):
            print(color + str(text) + Style.RESET_ALL)                    #function written by me
        else:
            print(color + str(text) + Style.RESET_ALL)
    else:
        print(text)

def get_user_input(): #function written by me
    
    """
    Get user input for game settings.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    global default_background, left, right, top, bottom, maximum_score_limit

# Dictionary containing colors and their RGB values
    color_dict = {
        "red": (203, 67, 53),
        "blue": (52, 152, 219),
        "yellow": (244, 208, 63),
        "black": (0, 0, 0),
        "gray": (127, 127, 127),
        "white": (255, 255, 255)
    }

    # Get default_background color
    default_background_input = input("Enter board background color *except white*: ")
    default_background = color_dict.get(default_background_input.lower(), default_background)

    #sets the color on the right and left, helping the users determine what side they are playing on
    right_input = input("Enter color for player on the left: ")
    right = color_dict.get(right_input.lower(), right)
    left_input = input("Enter color for player on the right: ")
    left = color_dict.get(left_input.lower(), left)
    
    #allow the user input the score that needs to be met for a player to win
    maximum_score_limit = int(input("Enter maximum game score (starting from 1): "))
    
    # Get paddle speed for both left and right paddles
    leftsided_paddleSpeed = int(input("Enter left paddle speed (0 to 100): "))
    leftsided_paddle.set_speed(leftsided_paddleSpeed)

    rightsided_paddleSpeed = int(input("Enter right paddle speed (0 to 100: "))
    rightsided_paddle.set_speed(rightsided_paddleSpeed)    

    
# Draw the Boundary of the game board
def boundary():
    
    """
    Draw the boundaries of the game board.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    global top, bottom, left, right     #written by me
    margin = 4
    rect_height = 50

    # Sets the coordinates where each part of the rectangle will connect
    # making the rectangle shape possible
    pygame.draw.rect(display, left, (0, 0, margin, height))
    pygame.draw.rect(display, top, (0, 0, width, margin))
    pygame.draw.rect(display, right, (width-margin, 0, margin, height))
    pygame.draw.rect(display, bottom, (0, height - margin, width, margin))

    # List of y-coordinates for the rectangle
    y_coordinates = [10, 60, 110, 160, 210, 260, 310, 360]    #written by me
    
    #white line in the middle of the screen, that divdes the game board into 2 different sides
    for y in y_coordinates:
        pygame.draw.rect(display, white, (width/2 - margin/2, y, margin, rect_height))     #written by me
        

# Paddle Class
class Paddle:
    def __init__(self, position_on_board):
        
        """
        Initialize a paddle object with a given position.

        Parameters
        ----------
        position : int
            Position of the paddle (-1 for left, 1 for right).
        """
        #paddle width and height
        self.w = 10
        self.h = self.w * 8
        
        #initiall paddle speed
        self.paddleSpeed = 0  

        if position_on_board == -1:
            #places the paddle on the left and right side of the screen
            self.x = 1.5 * margin
        else:
            self.x = width - 1.5 * margin - self.w
        
        #places paddles in the middle of the y coordinates, which is the paddle starting point
        self.y = height / 2 - self.h / 2


    # displays all parts of the Paddle and its color         
    def show(self):
        
        """
        Display the paddle on the screen.

        Parameters
        ----------
        None

        Returns
        -------
        None
        """
        pygame.draw.rect(display, white, (self.x, self.y, self.w, self.h))
        
            
    #function that allows user to move_pad the paddle
    def move_pad(self, ydirection):
        
        """
        Move the paddle based on the user input.

        Parameters
        ----------
        ydirection : int
            Direction of movement (-1 for up, 1 for down).

        Returns
        -------
        None
        """
        self.y = max(0, min(self.y + self.paddleSpeed * ydirection, height - self.h))
        
    
    #function that sets paddle speed
    def set_speed(self, speed): # function written by me
        
        """
        Set the paddle speed.

        Parameters
        ----------
        speed : int
            Speed of the paddle.

        Returns
        -------
        None
        """
        self.paddleSpeed = speed
        
        
# Create paddles on both sides of the board (-1) on the left and (+1) for the right
leftsided_paddle = Paddle(-1)
rightsided_paddle = Paddle(1)


class Ball:
    def __init__ (self,color):
        
        """
        Initialize a ball object with radius and a given color.

        Parameters
        ----------
        color : tuple
            RGB values representing the color of the ball.
        """
        self.r = 30 #ball radius is 30, showing how big the ball will be
        self.x = width/2 - self.r/2
        self.y = height/2 - self.r/2
        self.color = color
        self.angle = random.randint(-75, 75) # Set the initial angle of the ball to a random value between -75 and 75 degrees.
        
        # Randomize changes the ball direction by 180 degrees.
        if random.randint(0,1):
            self.angle += 180
        self.speed = 10
        
        
    def set_speed(self, speed): #function written by me
        
        """
        Set the ball speed.

        Parameters
        ----------
        speed : int
            Speed of the ball.

        Returns
        -------
        None
        """
        self.speed = speed
        
        
    
    #funtion that displays the ball on the screen, using the inbuilt ellipses as the ball shape
    def show(self):       
        
        """
        Display the ball on the screen.

        Parameters
        ----------
        None

        Returns
        -------
        None
        """
        pygame.draw.ellipse(display, self.color, (self.x, self.y, self.r, self.r))
    
    #fucntion that process ball movement
    def move(self):
        
        """
        Move the ball based on its angle and speed.

        Parameters
        ----------
        None

        Returns
        -------
        None
        """
        global left_players_score, right_players_score
        
        # Update the x and y coordinates of the ball in accordance to the current speed and angle
        self.x += self.speed*cos(radians(self.angle))
        self.y += self.speed*sin(radians(self.angle))
        
        # if the ball hits the wall on the right side, the player on the left would recieve a score increment
        # the ball will also change its angle
        if self.x + self.r > width - margin:
            left_players_score += 1
            self.angle = 180 - self.angle
            
        # if the ball hits the wall on the left side, the player on the right would recieve a score increment
        # the ball will also change its angle
        if self.x < margin:
            right_players_score += 1
            self.angle = 180 - self.angle
            
        # if the ball hits the wall on the top side, the ball would reflect off the wall and its angle would change
        if self.y < margin:
            self.angle = - self.angle
            
        # if the ball hits the wall on the bottom side, the ball would reflect off the wall and its angle would change
        if self.y + self.r  >=height - margin:
            self.angle = - self.angle
            
            
            
    # Check and Reflect the Ball when it hits the padddle
    def checkForPaddle(self):
        
        """
        Check if the ball hits a paddle and reflect its angle accordingly.

        Parameters
        ----------
        None

        Returns
        -------
        None
        """
        
        # Sets the y-coordinates for specific segments of the left paddle
        paddle_ranges = [
            (leftsided_paddle.y, leftsided_paddle.y + 10, -45),
            (leftsided_paddle.y + 10, leftsided_paddle.y + 20, -30),
            (leftsided_paddle.y + 20, leftsided_paddle.y + 30, -15),           #written by me
            (leftsided_paddle.y + 30, leftsided_paddle.y + 40, -10),
            (leftsided_paddle.y + 40, leftsided_paddle.y + 50, 10),
            (leftsided_paddle.y + 50, leftsided_paddle.y + 60, 15),
            (leftsided_paddle.y + 60, leftsided_paddle.y + 70, 30),
            (leftsided_paddle.y + 70, leftsided_paddle.y + 80, 45),
        ]
        
        #if the ball collides with the left or right paddle, the angle of the ball gets updated                         
        if self.x < width/2:                                                                                  #***********written by me*********
            if leftsided_paddle.x < self.x < leftsided_paddle.x + leftsided_paddle.w:
                for y_start, y_end, angle in paddle_ranges: #iterates through the y-coordinates for the left paddle
                    if y_start < self.y < y_end or y_start < self.y + self.r < y_end: #if the y-coordinates of the ball is in the right range
                        self.angle = angle #updates the ball's angle
                        break
                    
        #for the right paddle
        else:
            #if the ball collides with the right paddle, the angle of the ball gets updated
            if rightsided_paddle.x + rightsided_paddle.w > self.x  + self.r > rightsided_paddle.x:
                
                #if the segment of the right paddle is hit by the ball
                #I tried using a for loop like I did for the elft paddle, but the ball was not colliding, so I had to refer to the code I referenced
                if rightsided_paddle.y < self.y < leftsided_paddle.y + 10 or leftsided_paddle.y < self.y + self.r< leftsided_paddle.y + 10:
                    self.angle = -135
                if rightsided_paddle.y + 10 < self.y < rightsided_paddle.y + 20 or rightsided_paddle.y + 10 < self.y + self.r< rightsided_paddle.y + 20:
                    self.angle = -150
                if rightsided_paddle.y + 20 < self.y < rightsided_paddle.y + 30 or rightsided_paddle.y + 20 < self.y + self.r< rightsided_paddle.y + 30:
                    self.angle = -165
                if rightsided_paddle.y + 30 < self.y < rightsided_paddle.y + 40 or rightsided_paddle.y + 30 < self.y + self.r< rightsided_paddle.y + 40:
                    self.angle = 170
                if rightsided_paddle.y + 40 < self.y < rightsided_paddle.y + 50 or rightsided_paddle.y + 40 < self.y + self.r< rightsided_paddle.y + 50:
                    self.angle = 190
                if rightsided_paddle.y + 50 < self.y < rightsided_paddle.y + 60 or rightsided_paddle.y + 50 < self.y + self.r< rightsided_paddle.y + 60:
                    self.angle = 165
                if rightsided_paddle.y + 60 < self.y < rightsided_paddle.y + 70 or rightsided_paddle.y + 60 < self.y + self.r< rightsided_paddle.y + 70:
                    self.angle = 150
                if rightsided_paddle.y + 70 < self.y < rightsided_paddle.y + 80 or rightsided_paddle.y + 70 < self.y + self.r< rightsided_paddle.y + 80:
                     self.angle = 135    
                               
        
                                   

# Show the Score
def display_players_scores(): #function written by me
    
    """
    Display the scores of both players on the screen.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    
    #displays the scores for the left and right players
    leftScoreText = font.render("Left Players Score : " + str(left_players_score), True, darkorange) #written by me
    rightScoreText = font.render("Right Players Score : " + str(right_players_score), True, white)
    
    #displays the players scores at the 2 halfs of the boundary
    display.blit(leftScoreText, (3*margin, 3*margin))
    display.blit(rightScoreText, (width/2 + 3*margin, 3*margin))
    
    
# Game Over
def end_the_game(): # function written by me
    
    """
    Check if the game is over and display the winner.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    
    #simply, if the socre on the left or right is equal to the maximum score, the game ends
    if left_players_score == maximum_score_limit or right_players_score == maximum_score_limit:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: #closes the game if the user clicks the close button on the window
                    close_game_board()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q: #closes the game if the user click the 'Q' key
                        close_game_board()
                        
            # displays either the left or right player as the winner on the screen
            if left_players_score == maximum_score_limit:
                playerWins = largeFont.render(" The Left Player Wins!", True, green)
            elif right_players_score == maximum_score_limit:
                playerWins = largeFont.render("The Right Player Wins!", True, red)
            
            #positions the winner call out display, and updates the display
            display.blit(playerWins, (width/2 - 100, height/2))
            pygame.display.update()   



# function that allows the user to close the game
def close_game_board(): #function written by me
    """
    Close the game and exit the program.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    pygame.quit()
    sys.exit()
    
def board(): #function written by me
    """
    Initialize the game board, get user input, and start the game loop.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    global default_background, left, right, top, bottom, maximum_score_limit
    loop = True
    leftpad_moves_position = 0
    rightpad_moves_position = 0
    ball_color_index = 0
    ball_colors = ["white", "red", "blue", "yellow","green", "purple", "pink", "aquamarine"]
    
     # Define color_dict within the board function
    color_dict = {
        "red": (203, 67, 53),
        "blue": (52, 152, 219),
        "yellow": (244, 208, 63),
        "black": (0, 0, 0),
        "gray": (127, 127, 127),
        "white": (255, 255, 255),
        "green": (118,238,0),
        "purple": (178,58,238),
        "pink" : (255,20,147),
        "aquamarine" : (69,139,116),
    }
    
    
    #user instructions and prompts in different colors                   #written by me
    print_colored(" ")
    print_colored("                             Welcome to The 2 PLAYER Pong Game!", Fore.YELLOW)
    print_colored("                                     ***Instructions***", Fore.RED)
    print_colored("You can choose from the colors for the board background", Fore.GREEN)
    print_colored("    red", Fore.RED)
    print_colored("    blue", Fore.BLUE)
    print_colored("    yellow", Fore.YELLOW)
    print_colored("    black", Fore.BLACK)
    print_colored("    grey", Fore.WHITE)
    print_colored("- Press UP and DOWN arrow keys to control the right paddle.", Fore.CYAN)
    print_colored("- Press W and S keys to control the left paddle.", Fore.CYAN)
    print_colored("- Press M to increase the ball speed.", Fore.CYAN)
    print_colored("- Press C to change the ball color.", Fore.CYAN)
    print_colored("- Press Q to quit the game.", Fore.CYAN)
    print_colored("                                  ***Get ready to play!***", Fore.YELLOW)
    print_colored(" ")
    
    
    # Get user input before the game loop starts
    get_user_input()
    
    #the standard ball color will be red, before the user uses the key "C" to change the color
    ball = Ball(color_dict.get(ball_colors[ball_color_index], color_dict["white"]))

    
    # Run the game loop
    while True:                  #for loop written by me
        for event in pygame.event.get():
            # allows the user to exit the game by exiting at the top of the game window
            # allows the user to exit the game when they click on "Q" for quit
            if event.type == pygame.QUIT:
                close_game_board()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c: #changes the ball color when the user clicks "C"
                    ball_color_index = (ball_color_index + 1) % len(ball_colors)
                    ball.color = color_dict.get(ball_colors[ball_color_index], color_dict["white"])
                if event.key == pygame.K_q:
                    close_game_board()
                if event.key == pygame.K_UP: #paddle moves up when user presses the (up arrow) key
                    rightpad_moves_position = -1
                if event.key == pygame.K_DOWN:#paddle moves down when user presses the (down arrow) key
                    rightpad_moves_position = 1
                if event.key == pygame.K_w:#paddle moves up when user presses the (W) key
                    leftpad_moves_position = -1
                if event.key == pygame.K_s:#paddle moves down when user presses the (S) key
                    leftpad_moves_position = 1
                if event.key == pygame.K_m: #ball speed increases by 2 whenever the user presses the (M) key
                    ball.set_speed(ball.speed + 2)
            if event.type == pygame.KEYUP: #if none of the keys are being pressed, the paddle does not move
                leftpad_moves_position = 0
                rightpad_moves_position = 0
        
        
        leftsided_paddle.move_pad(leftpad_moves_position)
        rightsided_paddle.move_pad(rightpad_moves_position)
        ball.move()
        ball.checkForPaddle()
        
        # displays the game board itself
        display.fill(default_background)
        display_players_scores()
        
        # makes the paddles and ball visible on the screen
        ball.show()
        leftsided_paddle.show()
        rightsided_paddle.show()
        
        boundary()
        
        end_the_game()
        
        #pygame has an FPS feature, I set this to 60fps to make things smooth
        pygame.display.update()
        clock.tick(60)

# Start the game loop
board()


